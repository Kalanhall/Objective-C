# KLCircleProgress

[![CI Status](https://img.shields.io/travis/Kalanhall@163.com/KLCircleProgress.svg?style=flat)](https://travis-ci.org/Kalanhall@163.com/KLCircleProgress)
[![Version](https://img.shields.io/cocoapods/v/KLCircleProgress.svg?style=flat)](https://cocoapods.org/pods/KLCircleProgress)
[![License](https://img.shields.io/cocoapods/l/KLCircleProgress.svg?style=flat)](https://cocoapods.org/pods/KLCircleProgress)
[![Platform](https://img.shields.io/cocoapods/p/KLCircleProgress.svg?style=flat)](https://cocoapods.org/pods/KLCircleProgress)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

KLCircleProgress is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'KLCircleProgress'
```

## Author

Kalanhall@163.com, kalanhall@163.com

## License

KLCircleProgress is available under the MIT license. See the LICENSE file for more info.
