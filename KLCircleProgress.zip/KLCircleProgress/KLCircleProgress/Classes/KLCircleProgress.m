//
//  KLCircleProgress.m
//  KLCircleProgress
//
//  Created by Kalan on 2019/12/6.
//

#import "KLCircleProgress.h"

@implementation KLCircleConfig

- (UIColor *)backgroundColor
{
    if (_backgroundColor == nil) {
        _backgroundColor = [UIColor colorWithRed:151.0/255.0f green:151.0/255.0f blue:151.0/255.0f alpha:1];
    }
    return _backgroundColor;
}

- (UIColor *)startColor
{
    if (_startColor == nil) {
        _startColor = [UIColor colorWithRed:255.0/255.0f green:203.0/255.0f blue:0 alpha:1];
    }
    return _startColor;
}

- (UIColor *)endColor
{
    if (_endColor == nil) {
        _endColor = [UIColor colorWithRed:255.0/255.0f green:151.0/255.0f blue:0 alpha:1];
    }
    return _endColor;
}

- (CGFloat)lineWidth
{
    if (_lineWidth == 0) {
        _lineWidth = UIScreen.mainScreen.bounds.size.width * 0.1;
    }
    return _lineWidth;
}

@end

@interface KLCircleProgress ()

@property (strong, nonatomic) CAShapeLayer *trackLayer;
@property (strong, nonatomic) CAShapeLayer *progressLayer;
@property (strong, nonatomic) UIImageView *endPoint;
@property (strong, nonatomic) KLCircleConfig *config;

@end

static CGFloat const endPointMargin = 1.0;

@implementation KLCircleProgress

- (instancetype)initWithFrame:(CGRect)frame config:(KLCircleConfig *)config
{
    self = [super initWithFrame:frame];
    if (self) {
        self.config = config;
        
        float centerX = self.bounds.size.width  * 0.5;
        float centerY = self.bounds.size.height  * 0.5;
        /// 半径
        float radius = (self.bounds.size.width - config.lineWidth) * 0.5;
        
        /// 创建贝塞尔路径
        UIBezierPath *path =
        [UIBezierPath bezierPathWithArcCenter:CGPointMake(centerX, centerY)
                                       radius:radius
                                   startAngle:(-0.5f * M_PI)
                                     endAngle:1.5f * M_PI
                                    clockwise:YES];
        
        /// 添加背景圆环
        CAShapeLayer *backLayer = [CAShapeLayer layer];
        backLayer.frame = self.bounds;
        backLayer.fillColor =  [[UIColor clearColor] CGColor];
        backLayer.strokeColor  = config.backgroundColor.CGColor;
        backLayer.lineWidth = config.lineWidth;
        backLayer.path = [path CGPath];
        backLayer.strokeEnd = 1;
        [self.layer addSublayer:backLayer];
        
        /// 创建进度layer
        self.progressLayer = CAShapeLayer.layer;
        self.progressLayer.frame = self.bounds;
        self.progressLayer.fillColor =  [[UIColor clearColor] CGColor];
        /// 指定path的渲染颜色
        self.progressLayer.strokeColor  = [[UIColor blackColor] CGColor];
        self.progressLayer.lineCap = kCALineCapRound;
        self.progressLayer.lineWidth = config.lineWidth;
        self.progressLayer.path = [path CGPath];
        self.progressLayer.strokeEnd = 0;
        
        /// 设置渐变颜色
        CAGradientLayer *gradientLayer =  [CAGradientLayer layer];
        gradientLayer.frame = self.bounds;
        NSArray *colors = @[(id)config.startColor.CGColor, (id)config.endColor.CGColor];
        [gradientLayer setColors:colors];
        gradientLayer.startPoint = CGPointMake(0, 0);
        gradientLayer.endPoint = CGPointMake(0, 1);
        /// 用progressLayer来截取渐变层
        [gradientLayer setMask:self.progressLayer];
        [self.layer addSublayer:gradientLayer];
        
        
        /// 用于显示结束位置的小点
        self.endPoint = [[UIImageView alloc] init];
        self.endPoint.frame = CGRectMake(0, 0, config.lineWidth - endPointMargin * 2, config.lineWidth - endPointMargin * 2);
        self.endPoint.hidden = true;
    //    self.endPoint.backgroundColor = [UIColor blackColor];
    //    self.endPoint.image = [UIImage imageNamed:@"endPoint"];
        self.endPoint.layer.masksToBounds = true;
        self.endPoint.layer.cornerRadius = self.endPoint.bounds.size.width/2;
        [self addSubview:self.endPoint];
    }
    return self;
}

-(void)setProgress:(CGFloat)progress
{
    _progress = progress;
    _progressLayer.strokeEnd = progress;
    [self updateEndPoint];
    [_progressLayer removeAllAnimations];
}

/// 更新小点的位置
-(void)updateEndPoint
{
    //转成弧度
    CGFloat angle = M_PI*2*_progress;
    float radius = (self.bounds.size.width - self.config.lineWidth) * 0.5;
    int index = angle / M_PI_2; // 用户区分在第几象限内
    float needAngle = angle - index*M_PI_2; // 用于计算正弦/余弦的角度
    float x = 0,y = 0; // 用于保存_dotView的frame
    switch (index) {
        case 0:
            NSLog(@"第一象限");
            x = radius + sinf(needAngle)*radius;
            y = radius - cosf(needAngle)*radius;
            break;
        case 1:
            NSLog(@"第二象限");
            x = radius + cosf(needAngle)*radius;
            y = radius + sinf(needAngle)*radius;
            break;
        case 2:
            NSLog(@"第三象限");
            x = radius - sinf(needAngle)*radius;
            y = radius + cosf(needAngle)*radius;
            break;
        case 3:
            NSLog(@"第四象限");
            x = radius - cosf(needAngle)*radius;
            y = radius - sinf(needAngle)*radius;
            break;
            
        default:
            break;
    }
    
    /// 更新圆环的frame
    CGRect rect = self.endPoint.frame;
    rect.origin.x = x + endPointMargin;
    rect.origin.y = y + endPointMargin;
    self.endPoint.frame = rect;
    /// 移动到最前
    [self bringSubviewToFront:self.endPoint];
    self.endPoint.hidden = false;
    if (self.progress == 0 || self.progress == 1) {
        self.endPoint.hidden = true;
    }
}

@end
