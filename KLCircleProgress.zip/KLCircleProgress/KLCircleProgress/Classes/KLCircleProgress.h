//
//  KLCircleProgress.h
//  KLCircleProgress
//
//  Created by Kalan on 2019/12/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KLCircleConfig : NSObject

@property (strong, nonatomic) UIColor *backgroundColor;
@property (strong, nonatomic) UIColor *startColor;
@property (strong, nonatomic) UIColor *endColor;
@property (assign, nonatomic) CGFloat lineWidth;

@end

@interface KLCircleProgress : UIView

@property (assign, nonatomic) CGFloat progress;

- (instancetype)initWithFrame:(CGRect)frame config:(KLCircleConfig *)config;

@end

NS_ASSUME_NONNULL_END
