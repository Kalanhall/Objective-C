//
//  KLViewController.m
//  KLCircleProgress
//
//  Created by Kalanhall@163.com on 12/06/2019.
//  Copyright (c) 2019 Kalanhall@163.com. All rights reserved.
//

#import "KLViewController.h"
@import KLCircleProgress;

@interface KLViewController ()

@property (strong, nonatomic) KLCircleProgress *progressView;

@end

@implementation KLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    CGRect rect = CGRectMake(20, 100, self.view.bounds.size.width - 40, self.view.bounds.size.width - 40);
    KLCircleConfig *config = KLCircleConfig.alloc.init;
//    config.backgroundColor = UIColor.orangeColor;
//    config.startColor = UIColor.redColor;
//    config.endColor = UIColor.blueColor;
//    config.lineWidth = 30;
    self.progressView = [KLCircleProgress.alloc initWithFrame:rect config:config];
    self.progressView.progress = 0.5;
    [self.view addSubview:self.progressView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
